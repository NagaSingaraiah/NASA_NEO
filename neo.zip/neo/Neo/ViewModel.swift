//
//  ViewModel.swift
//  Neo
//
//  Created by 1356184 on 06/02/23.
//

import Foundation
import UIKit

class ViewModel {
    static let sharedInstance = ViewModel()
    let jsonDecoder = JSONDecoder()
    var neoDataArray = [near_earth_objects]()
    var dateWiseCount = [Int]()
    
    typealias successCallBack = (_ keyNames: [String], _ astroidData: [near_earth_objects], _ astroidCount: [Int]) -> Void
    typealias failureCallBack = (_ error: String) -> Void

    func getNeoData(startDate: String, endDate:String, success: @escaping successCallBack, failure: @escaping failureCallBack) {
        let url = URL(string: "https://api.nasa.gov/neo/rest/v1/feed?start_date=\(startDate)&end_date=\(endDate)&api_key=DEMO_KEY")
        
        Services.sharedInstance.getRequest(url: url!) { data in
            self.neoDataArray.removeAll()
            self.dateWiseCount.removeAll()
            let finalResult = try! self.jsonDecoder.decode(Model.self, from: data)
            let keys = Array(finalResult.near_earth_objects.keys)
            for k in keys {
                self.neoDataArray.append(contentsOf: finalResult.near_earth_objects[k]!)
                let c = (finalResult.near_earth_objects[k]!).count
                self.dateWiseCount.append(c)
            }
            success(keys, self.neoDataArray, self.dateWiseCount)
        } failure: { error in
            failure(error)
        }
    }
}
