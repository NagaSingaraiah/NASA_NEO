//
//  DataModel.swift
//  Neo
//
//  Created by 1356184 on 06/02/23.
//

import Foundation

struct Model: Codable {
//    let elementCount: Int
    var near_earth_objects: [String: [near_earth_objects]]
}

struct near_earth_objects: Codable {
    var id, neo_reference_id, name: String
    var close_approach_data: [close_approach_data]
}

struct close_approach_data: Codable {
    var close_approach_date: String
    var relative_velocity: relative_velocity
    var miss_distance: miss_distance
}

struct relative_velocity: Codable {
    var kilometers_per_hour: String
}

struct miss_distance: Codable {
    var kilometers: String
}
