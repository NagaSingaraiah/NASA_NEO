//
//  LoadingIndicator.swift
//  
//
//  Created by 1356184 on 07/02/23.
//

import Foundation
import UIKit

class LoadingIndicator: UIView {
    
    @IBOutlet weak var baseview: UIView!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var textLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    class var sharedInstance : LoadingIndicator {
        struct Static {
            static let instance : LoadingIndicator = UINib(nibName: "LoadingIndicator", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! LoadingIndicator
        }
        return Static.instance
    }
    
    func setupUI() {
        self.indicator.hidesWhenStopped = true
        self.baseview.layer.cornerRadius = 12;
        self.baseview.layer.masksToBounds = false;
        self.baseview.layer.shadowOffset = CGSize(width: 6, height: 6)
        self.baseview.layer.shadowRadius  = 6;
        self.baseview.layer.shadowColor = UIColor.black.cgColor
        self.baseview.layer.shadowOpacity = 0.6;
        self.textLabel.textColor = UIColor.white
    }
    
    func show() {
        DispatchQueue.main.async {
            self.indicator .startAnimating()
            var window:UIWindow? = UIApplication.shared.keyWindow!
            
            if let _:UIWindow = window {
                window = UIApplication.shared .windows[0]
            }
            self.center = (window?.center)!
            window?.addSubview(self)
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }
    
    
    func hide() {
        DispatchQueue.main.async {
            self.indicator .stopAnimating()
            self.removeFromSuperview()
            while UIApplication.shared .isIgnoringInteractionEvents {
                UIApplication.shared.endIgnoringInteractionEvents()
            }
        }
    }
    
}
