//
//  ViewController.swift
//  neo
//
//  Created by 1356184 on 06/02/23.
//

import UIKit
import Charts

class ViewController: UIViewController, ChartViewDelegate {

    @IBOutlet var startDateTextField: UITextField!
    @IBOutlet var endDateTextField: UITextField!
    @IBOutlet var barChartView: BarChartView!
    @IBOutlet var submitButton: UIButton!
    @IBOutlet var fastestAstroidLabel: UILabel!
    @IBOutlet var closestAstroidLabel: UILabel!
    @IBOutlet var statsView: UIView!
    
    let datePicker = UIDatePicker()
    var tempTextField: UITextField?
    var astroidList = [near_earth_objects]()
    var astroidDate = [String]()
    var astroidCount = [Int]()
    var missDistance = [Float]()
    var relativeVelocity = [Float]()
    var barChart = BarChartView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startDateTextField.delegate = self
        endDateTextField.delegate = self
        submitButton.isEnabled = false
        statsView.isHidden = true
    }

    @IBAction func submitButtonClicked(_ sender: Any) {
        resetAll()
        LoadingIndicator.sharedInstance.show()
        ViewModel.sharedInstance.getNeoData(startDate: startDateTextField.text!, endDate: endDateTextField.text!) { keyNames, astroidData, astroidCount  in
            LoadingIndicator.sharedInstance.hide()
            DispatchQueue.main.async {
                self.statsView.isHidden = false
            }
            self.astroidDate = keyNames
            self.astroidCount = astroidCount
            self.astroidList = astroidData
            self.calculateStats()
            self.setupBarchart()
        } failure: { error in
            LoadingIndicator.sharedInstance.hide()
            print(error)// throws alert at this instance
        }
    }
    
    func calculateStats() {
        for astroid in astroidList {
            missDistance.append(Float(astroid.close_approach_data[0].miss_distance.kilometers) ?? 0)
            relativeVelocity.append(Float(astroid.close_approach_data[0].relative_velocity.kilometers_per_hour) ?? 0)
        }
        DispatchQueue.main.async {
            self.closestAstroidLabel.text = "\(self.missDistance.min()!)"
            self.fastestAstroidLabel.text = "\(self.relativeVelocity.max()!)"
        }
   }
    
    func setupBarchart() {
        var entries = [BarChartDataEntry]()
        for i in 0..<astroidDate.count {
            entries.append(BarChartDataEntry(x: Double(i), y: Double(astroidCount[i])))
        }
        let set = BarChartDataSet(entries: entries)
        let data = BarChartData(dataSet: set)
        DispatchQueue.main.async {
            self.barChart = BarChartView(frame: CGRect(x: 0, y: 0, width: self.barChartView.frame.size.width, height: self.barChartView.frame.size.height))
            self.barChart.setExtraOffsets(left: 10, top: 30, right: 20, bottom: 50)
            self.barChart.data = data
            self.barChart.xAxis.labelPosition = .bottom
            self.barChart.xAxis.valueFormatter = IndexAxisValueFormatter.with(values: self.astroidDate)
            self.barChart.xAxis.labelRotationAngle = -25
            self.barChart.xAxis.labelTextColor = UIColor.white
            self.barChart.leftYAxisRenderer.axis.labelTextColor = UIColor.white
            self.barChart.rightYAxisRenderer.axis.labelTextColor = UIColor.white
            self.barChart.barData?.setValueTextColor(NSUIColor.white)
            self.barChart.barData?.setValueFont(NSUIFont.systemFont(ofSize: 12))
            self.barChart.legend.textColor = UIColor.white
            self.barChartView.addSubview(self.barChart)
        }
    }
    
    func resetAll() {
        astroidDate.removeAll()
        astroidCount.removeAll()
        missDistance.removeAll()
        missDistance.removeAll()
        relativeVelocity.removeAll()
        barChart.removeFromSuperview()
        statsView.isHidden = true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if (startDateTextField.text != "") && (endDateTextField.text != "") {
            submitButton.isEnabled = true
        } else {
            submitButton.isEnabled = false
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        tempTextField = textField
        presentDatePicker()
    }
    
    func presentDatePicker(){
        //Formate Date
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels

        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Clear", style: .plain, target: self, action: #selector(cancelDatePicker));
        datePicker.center = view.center
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        tempTextField?.inputAccessoryView = toolbar
        tempTextField?.inputView = datePicker
        
    }
    
    @objc func donedatePicker(){
        print(datePicker.date)
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        tempTextField?.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
}
