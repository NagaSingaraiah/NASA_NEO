//
//  Services.swift
//  Neo
//
//  Created by 1356184 on 07/02/23.
//

import Foundation

class Services {
    
    static let sharedInstance = Services() // singleton class
    //GET method
    func getRequest(url: URL, success: @escaping(_ data: Data) -> Void, failure: @escaping (_ error: String) -> Void) {
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        //let session = URLSession.shared
        let session = URLSession(
            configuration: URLSessionConfiguration.ephemeral,
            delegate: NSURLSessionPinningDelegate(),
            delegateQueue: nil)
        let task  = session.dataTask(with: request) {data, resp, error in
            if let data = data {
                success(data)
            } else {
                failure(String(describing: error))
            }
        }
        task.resume()
    }
    
    //POST method
}
